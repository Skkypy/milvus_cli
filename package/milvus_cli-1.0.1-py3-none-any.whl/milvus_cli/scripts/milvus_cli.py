from .connection_cli import *
from .helper_cli import *
from .database_cli import *
from .collection_cli import *
from .index_cli import *
from .data_cli import *
from .user_cli import *
from .alias_cli import *
from .partition_cli import *
from .role_cli import *

if __name__ == "__main__":
    runCliPrompt()
